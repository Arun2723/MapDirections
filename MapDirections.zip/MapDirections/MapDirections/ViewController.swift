//
//  ViewController.swift
//  MapDirections
//
//  Created by ARUN S S on 04/10/23.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {

    @IBOutlet weak var textFieldForAddress: UITextField!
    @IBOutlet var getDirectionsButton: UIButton!
    @IBOutlet var map: MKMapView!
    
    var locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestAlwaysAuthorization()
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        
        map.delegate = self
    }

    @IBAction func getDirectionsTapped(_ sender: Any) {
        getAddress()
    }
    
    func getAddress() {
        let geoCoder = CLGeocoder()
        geoCoder.geocodeAddressString(textFieldForAddress.text!) { (placemarks, error)in
            guard let placemarks = placemarks, let location = placemarks.first?.location
            else {
                print("No Location Found")
                return
            }
                 print(location)
            self.mapThis(destinaionCord: location.coordinate)
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print(locations)
    }
}

func mapThis(destinaionCord : CLLocationCoordinate2D){

    let sourceCoordinate = (locationManager.location?.coordinate)!
    
    let sourcePlaceMark = MKPlacemark(coordinate: sourceCoordinate)
    
    let destPlaceMark = MKPlacemark(coordinate: destinationCoord)
    let sourceItem = MKMapItem(placemark: sourcePlaceMark)
    let destItem = MKMapItem(placemark: destPlaceMark)
    
    let destinationRequest = MKDirections.Request()
    destinationRequest.source = sourceItem
    destinationRequest.destination = destItem
    destinationRequest.transportType = .automobile
    destinationRequest.requestsAlternateRoutes = true
    
    let directions = MKDirections(request: destinationRequest)
    directions.calculate { (response, error) in
        guard let response = response else{
            if let error = error {
                print("Something is Wrong :(")
            }
            return
        }
        let route = response.routes[0]
        self.map.addOverlay(route.polyline)
        self.map.setVisibleMapRect(route.polyline.boundingMapRect, animated: true)
    }
    
    func mapView(_ mapView: MKMapView, renderFor overlay: MKOverlay) -> MKOverlayRenderer {
        let render = MKPolylineRenderer(overlay: overlay as! MKPolyline)
        render.strokeColor = .blue
        return render
    }
}

